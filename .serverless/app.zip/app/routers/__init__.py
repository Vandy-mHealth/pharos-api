from .landmark import landmark_router
from .network import network_router
from .photo import photo_router
from .user import user_router
